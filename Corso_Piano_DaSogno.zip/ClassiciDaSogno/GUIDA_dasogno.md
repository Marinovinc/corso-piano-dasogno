# Classici da sogno al pianoforte — guida

`[sessione 3c88c123, 04/10/2026]` — brani classici celebri, **interi e corretti**, da MIDI di
**pubblico dominio** (Mutopia, CC0). Due righe (Right/Left Hand) per Synthesia.

**Avvertenza onesta sulla difficolta':** questi **NON sono brani per principianti**. Sono i pezzi
"da sogno" — bellissimi e famosi, ma di livello **intermedio/avanzato**. Puoi usarli in due modi:
(1) ascoltarli e sognare di suonarli; (2) studiarli **lentissimi** con la modalita' di attesa di
Synthesia, una mano alla volta, una battuta al giorno. Con pazienza si arriva anche qui.

---

## I brani (2, integrali)

| # | File | Autore | Durata | Livello |
|---|---|---|---|---|
| 1 | `1_Clair_de_Lune` | Debussy | ~5:20 | avanzato |
| 2 | `2_Gymnopedie_n1` | Satie | ~2:20 | intermedio |

Sono le **versioni complete**, non temi ridotti: note esatte dalla fonte.

---

## Onesta' sui file

MIDI di pubblico dominio (Mutopia, CC0 "nessun diritto riservato"), adattati a due mani con
`adatta_midi_pd.py`. Le note sono quelle originali del brano: niente trascrizioni a mano, niente
errori. Pezzi interi. Buon ascolto e buono studio.
